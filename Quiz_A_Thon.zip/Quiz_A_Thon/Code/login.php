<?php
	require('database.php');
	session_start();
	if(isset($_SESSION["email"]))
	{
		session_destroy();
	}
	
	$ref=@$_GET['q'];		
	if(isset($_POST['submit']))
	{	
		$email = $_POST['email'];
		$pass = $_POST['password'];
		$email = stripslashes($email);
		$email = addslashes($email);
		$pass = stripslashes($pass); 
		$pass = addslashes($pass);
		$email = mysqli_real_escape_string($con,$email);
		$pass = mysqli_real_escape_string($con,$pass);					
		$str = "SELECT * FROM user WHERE email='$email' and password='$pass'";
		$result = mysqli_query($con,$str);
		if((mysqli_num_rows($result))!=1) 
		{
			echo "<center><h3><script>alert('Sorry.. Wrong Username (or) Password');</script></h3></center>";
			header("refresh:0;url=login.php");
		}
		else
		{
			$_SESSION['logged']=$email;
			$row=mysqli_fetch_array($result);
			$_SESSION['name']=$row[1];
			$_SESSION['id']=$row[0];
			$_SESSION['email']=$row[2];
			$_SESSION['password']=$row[3];
			header('location: welcome.php?q=1'); 					
		}
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Login | QuizBuzz</title>
    <style type="text/css">
			body {
        font-family: Lato, Helvetica, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
        width: 100%;
        background: url(image/book.png);
        background-position: center center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }

      h1 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 400;
        line-height: 1.1;
        font-size: 63px;
        font-stretch: extra-condensed;
        margin-bottom: 0;
      }

      h2 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 500;
        font-size: 40px;
        line-height: 1.1;
        font-stretch: condensed;
      }

      p {
        margin-top: 10px;
        color: white;
      }

      table {
        padding: 20px;
        background-color: #545458;
        width: 40%;
        border-radius: 5px
      }

      th {
        font-size: 35px;
        font-weight: bold;
        font-stretch: extra-condensed;
      }

      td {
        color: white;
        font-size: 15px;
      }

      i {
        color: white;
        font-size: 90px;
        width: 40px;
      }

      input,
      textarea {
        font: inherit;
        padding: 8px 16px 8px 16px;
        width: 90%;
        background-color: #f0ecec;
        border-style: none;
        border-radius: 3px
      }

      .form-control {
        display: block;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
      }

      .btn {
        display: inline-block;
        margin-bottom: 0;
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        border: none;
        padding: 8px 16px;
        font-size: 16px;
        line-height: 1.58;
        border-radius: 50px;
        color: #fff;
        background-color:black;
      }

      </style>
	</head>

	<body>
	
		<center>
		<form method="post" action="login.php" enctype="multipart/form-data">
			<h2>Login</h2>
			<table cellspacing=10px>
				<tr>
					<td><label>Email ID:</label></td>	
				</tr>
				<tr>
					<td><input type="email" name="email" class="form-control"></td>
				</tr>
				<tr>
					<td>
						<label class="fw">Password:
							
						</label>
					</td>
				</tr>
				<tr>
					<td><input type="password" name="password" class="form-control"></td>
				</tr>
				<tr>
					<td><button class="btn" name="submit">Login</button> 
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="admin.php" class="btn" style="text-decoration:none;">Admin</a></td>
				</tr>
				<tr>
					<td><p class="message"><span>Don't have an account?</span> <a href="register.php">Register</a> Here..</p></td>
				</tr>

			</table>
		</form>
		</center>
	</body>
</html>