<?php
    include_once 'database.php';
    session_start();
    if(isset($_SESSION["email"]))
	{
		session_destroy();
    }
    
    $ref=@$_GET['q'];
    if(isset($_POST['submit']))
	{	
        $email = $_POST['email'];
        $password = $_POST['password'];

        $email = stripslashes($email);
        $email = addslashes($email);
        $password = stripslashes($password); 
        $password = addslashes($password);

        $email = mysqli_real_escape_string($con,$email);
        $password = mysqli_real_escape_string($con,$password);
        
        $result = mysqli_query($con,"SELECT email FROM admin WHERE email = '$email' and password = '$password'") or die('Error');
        $count=mysqli_num_rows($result);
        if($count==1)
        {
            session_start();
            if(isset($_SESSION['email']))
            {
                session_unset();
            }
            $_SESSION["name"] = 'Admin';
            $_SESSION["key"] ='admin';
            $_SESSION["email"] = $email;
            header("location:dashboard.php?q=0");
        }
        else
        {
            echo "<center><h3><script>alert('Sorry.. Wrong Username (or) Password');</script></h3></center>";
            header("refresh:0;url=admin.php");
        }
    }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Login | QuizBuzz</title>
    <style>

      body {
        font-family: Lato, Helvetica, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
        width: 100%;
        background: url(image/book.png);
        background-position: center center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }

      h1 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 400;
        line-height: 1.1;
        font-size: 63px;
        font-stretch: extra-condensed;
        margin-bottom: 0;
      }

      h2 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 500;
        font-size: 40px;
        line-height: 1.1;
        font-stretch: condensed;
      }

      p {
        margin-top: 10px;
        color: white;
      }

      table {
        padding: 20px;
        background-image: linear-gradient(180deg,black,grey);
        width: 40%;
        border-radius: 5px
      }

      th {
        font-size: 35px;
        font-weight: bold;
        font-stretch: extra-condensed;
      }

      td {
        color: #555555;
        font-size: 15px;
      }

      i {
        color: white;
        font-size: 90px;
        width: 40px;
      }

      input,
      textarea {
        font: inherit;
        padding: 8px 16px 8px 16px;
        width: 90%;
        background-color: #f0ecec;
        border-style: none;
        border-radius: 3px
      }

      .form-control {
        display: block;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
      }

      .btn {
        display: inline-block;
        margin-bottom: 0;
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        border: none;
        padding: 8px 16px;
        font-size: 16px;
        line-height: 1.58;
        border-radius: 50px;
        color: #fff;
        background-color:black;
      }
    </style>
  </head>
  <body>

              <center>
                <h2 style="font-family: Noto Sans;">Login to </h2>
                <h2 style="font-family: Noto Sans;">Admin Page</h2>
              </center>
              <br>
              <center>

              
              <form method="post" action="admin.php" enctype="multipart/form-data">
                <table>
                    <div>
                    <tr>
                        <td><label> <p>Email ID:</p>
                            </label></td>
                    </tr>
                    <tr>
                        <td><input type="email" name="email" class="form-control"></td>
                    </tr>
                    </div>
                    <div>
                    <tr>
                        <td> <p><label>Enter Your Password: </label></td>
                    </p>
                            </tr>
                    <tr>
                        <td><input type="password" name="password"></td>
                    </tr>
                    </div>
                    <div>
                        <tr>
                            <td><br><button class="btn" name="submit">Login</button></td>
                        </tr>
                </div>

                </table>
    
                
              </form>
              </center>

  </body>
</html>