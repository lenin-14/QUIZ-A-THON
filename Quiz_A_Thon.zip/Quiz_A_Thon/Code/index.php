<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>| Quiz A Thon |</title>
        <style>
            body {
                width: 100%;
                background: url(image/book.png) ;
                background-position: center center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
            .btn
            {
                background-color: grey;
                color: white;
                padding: 15px 25px;
                text-decoration: none;
                border-radius:10px;
            }
            .btn:hover {
            background-color: black;
            color:orange;
            }
            p
            {
                font-size:60px;
                color: red;
            }
            h2
            {
                color:white;
            }
        </style>
    </head>
    <body>
        <center>
            <div class="intro"><br><br><br>
                <p><b> QUIZ A THON </b></p>
                <a href="login.php" class="btn"> Login </a> &emsp;
                <a href="register.php" class="btn"> Register </a><br><br><br>
                <h2> Become &nbsp;an Expert. </h2>
            </div>
        </center>
    </body>
</html>