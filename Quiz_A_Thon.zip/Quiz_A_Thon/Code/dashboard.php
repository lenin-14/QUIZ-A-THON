<?php
    include_once 'database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        include_once 'database.php';
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard | QuizBuzz</title>
    <style>
        body {
        font-family: Lato, Helvetica, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
        width: 100%;
        background: url(image/book.png);
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }

      h1 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 400;
        line-height: 1.1;
        font-size: 63px;
        font-stretch: extra-condensed;
        margin-bottom: 0;
      }

      h2 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 500;
        font-size: 40px;
        line-height: 1.1;
        font-stretch: condensed;
      }

      p {
        margin-top: 10px;
        color: white;
      }

      table {
        padding: 20px;
        background-color: #545458 ;
        width: 80%;
        border-radius: 5px;
        margin-top: 10px;
      }

      th {
        font-size: 35px;
        font-weight: bold;
        font-stretch: extra-condensed;
      }

      td {
        color: white;
        font-size: 15px;
      }

      i {
        color: white;
        font-size: 90px;
        width: 40px;
      }
      
      input,
      textarea {
        font: inherit;
        padding: 8px 16px 8px 16px;
        width: 90%;
        background-color: #f0ecec;
        border-style: none;
        border-radius: 3px
      }

      .form-control {
        display: block;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
      }

      .btn {
        display: inline-block;
        margin-bottom: 0;
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        border: none;
        padding: 8px 16px;
        font-size: 13px;
        line-height: 1.58;
        border-radius: 50px;
        color: #fff;
        background-color:black;
      }
      .a6
      {
        height:10px;
      }
         ul.nav {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }  
        ul.nav li {
            float: left;
        }
        ul.nav li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        ul.nav li a:hover:not(.active) {
            background-color: #111;
        }

        ul.nav li a.active {
            background-color: purple;
        }

        ul.nav li.right {
            float: right;
        }
        .f6
        {
            padding: bottom 30px;
            color:white;
        }


        @media screen and (max-width: 600px) {
            ul.nav li.right, 
            ul.nav li {float: none;}
        }
    </style>
</head>

<body>
        <div>
            <div>
                <ul class="nav">
                    <li <?php if(@$_GET['q']==0) echo'class="active"'; ?>><a href="dashboard.php?q=0">Home</a></li>
                    <li <?php if(@$_GET['q']==1) echo'class="active"'; ?>><a href="dashboard.php?q=1">User</a></li>
                    <li <?php if(@$_GET['q']==2) echo'class="active"'; ?>><a href="dashboard.php?q=2">Ranking</a></li>
                    <li class="dropdown <?php if(@$_GET['q']==4 || @$_GET['q']==5) echo'active"'; ?>">
                    <li><a href="dashboard.php?q=4">Add Quiz</a></li>
                    <li><a href="dashboard.php?q=5">Remove Quiz</a></li>
                    <li <?php if(@$_GET['q']==6) echo'class="active"'; ?>><a href="dashboard.php?q=6">Send Email</a></li>
                    <li class="right" <?php echo''; ?> > <a href="logout1.php?q=dashboard.php">&nbsp;Log out</a></li>

                </ul>
            </div>
        </div>

    <div>
        <div>
        
                <?php if(@$_GET['q']==0)
                {
                   echo "<h1> Welcome To Admin Page!!</h1>";
					
                }

                if(@$_GET['q']== 2) 
                {
                    $q=mysqli_query($con,"SELECT * FROM rank  ORDER BY score DESC " )or die('Error223');
                    echo  '<div><div>
                    <center><table class="table>
                    <tr style="color:red"><td><center><b>Rank</b></center></td><td><center><b>Name</b></center></td><td><center><b>Score</b></center></td></tr>';
                    $c=0;
                    while($row=mysqli_fetch_array($q) )
                    {
                        $e=$row['email'];
                        $s=$row['score'];
                        $q12=mysqli_query($con,"SELECT * FROM user WHERE email='$e' " )or die('Error231');
                        while($row=mysqli_fetch_array($q12) )
                        {
                            $name=$row['name'];
                            $college=$row['college'];
                        }
                        $c++;
                        echo '<tr><td style="color:#99cc32"><center><b>'.$c.'</b></center></td><td><center>'.$e.'</center></td><td><center>'.$s.'</center></td>';
                    }
                    echo '</table></center></div></div>';
                }
                ?>
                <?php 
                    if(@$_GET['q']==1) 
                    {
                        $result = mysqli_query($con,"SELECT * FROM user") or die('Error');
                        echo  '<div><div><center><table>
                        <tr><td><center><b>S.N.</b></center></td><td><center><b>Name</b></center></td><td><center><b>College</b></center></td><td><center><b>Email</b></center></td><td><center><b>Action</b></center></td></tr>';
                        $c=1;
                        while($row = mysqli_fetch_array($result)) 
                        {
                            $name = $row['name'];
                            $email = $row['email'];
                            $college = $row['college'];
                            echo '<tr><td><center>'.$c++.'</center></td><td><center>'.$name.'</center></td><td><center>'.$college.'</center></td><td><center>'.$email.'</center></td><td><center><a title="Delete User" href="update.php?demail='.$email.'"></a></center></td></tr>';
                        }
                        $c=0;
                        echo '</table></center></div></div>';
                    }
                ?>

                <?php
                    if(@$_GET['q']==4 && !(@$_GET['step']) ) 
                    {
                        echo '<div><span style="margin-left:40%;font-size:30px;color:#fff;"><b>Enter Quiz Details</b></span><br /><br />
                        <div>
                        <center>
                        <form name="form" action="update.php?q=addquiz"  method="POST">
                            <table style="width:50%">
                            <tr><td><input id="name" name="name" placeholder="Enter Quiz title" type="text"></td></tr>

                            <tr><td><input id="total" name="total" placeholder="Enter total number of questions" type="number"></td></tr>
                            <tr><td><input id="right1" name="right1" placeholder="Enter marks on correct answer" min="0" type="number"></td></tr>
                            <tr><td><input id="wrong" name="wrong" placeholder="Enter minus marks on wrong answer without sign" min="0" type="number"></td></tr>
                            <tr><td><input id="diff" name="diff" placeholder="Enter difficulty" min="0" type="text"></td></tr>
                            <tr><td><center><input type="submit" value="Submit" class="btn" style="width:100px"/></center></td></tr>

                            </table>
                        </form>
                        </center>

                                
                        </div>';
                    }
                ?>

                <?php
                    if(@$_GET['q']==4 && (@$_GET['step'])==2 ) 
                    {
                        echo ' 
                        <div class="row">
                        <span style="margin-left:40%;font-size:30px;"><b>Enter Question Details</b></span><br /><br />
                        <div ></div><div><form name="form" action="update.php?q=addqns&n='.@$_GET['n'].'&eid='.@$_GET['eid'].'&ch=4 "  method="POST">
                        <fieldset>
                        ';
                
                        for($i=1;$i<=@$_GET['n'];$i++)
                        {
                            echo '<b>Question number&nbsp;'.$i.'&nbsp;:</><br /><!-- Text input-->
                                    <div>
                                        <label for="qns'.$i.' "></label>  
                                        <div>
                                            <textarea rows="3" cols="5" name="qns'.$i.'" class="form-control" placeholder="Write question number '.$i.' here..."></textarea>  
                                        </div>
                                    </div>
                                    <div>
                                        <label for="'.$i.'1"></label>  
                                        <div>
                                            <input id="'.$i.'1" name="'.$i.'1" placeholder="Enter option a" type="text">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="'.$i.'2"></label>  
                                        <div>
                                            <input id="'.$i.'2" name="'.$i.'2" placeholder="Enter option b" type="text">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="'.$i.'3"></label>  
                                        <div>
                                            <input id="'.$i.'3" name="'.$i.'3" placeholder="Enter option c" type="text">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="'.$i.'4"></label>  
                                        <div>
                                            <input id="'.$i.'4" name="'.$i.'4" placeholder="Enter option d" type="text">
                                        </div>
                                    </div>
                                    <br />
                                    <b>Correct answer</b>:<br />
                                    <select id="ans'.$i.'" name="ans'.$i.'" placeholder="Choose correct answer " >
                                    <option value="a">Select answer for question '.$i.'</option>
                                    <option value="a"> option a</option>
                                    <option value="b"> option b</option>
                                    <option value="c"> option c</option>
                                    <option value="d"> option d</option> </select><br /><br />'; 
                        }
                        echo '<div>
                                <label for=""></label>
                                <div> 
                                    <input  type="submit" style="margin-left:45%" class="btn" value="Submit"/>
                                </div>
                              </div>

                        </fieldset>
                        </form></div>';
                    }
                ?>

                <?php 
                    if(@$_GET['q']==5) 
                    {
                        $result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
                        echo  '<div><div><center><table class="table table-striped">
                        <tr><td><center><b>S.N.</b></center></td><td><center><b>Topic</b></center></td><td><center><b>Total question</b></center></td><td><center><b>Marks</b></center></td><td><center><b>Action</b></center></td></tr>';
                        $c=1;
                        while($row = mysqli_fetch_array($result)) {
                            $title = $row['title'];
                            $total = $row['total'];
                            $sahi = $row['sahi'];
                            $eid = $row['eid'];
                            echo '<tr><td><center>'.$c++.'</center></td><td><center>'.$title.'</center></td><td><center>'.$total.'</center></td><td><center>'.$sahi*$total.'</center></td>
                            <td><center><b><a href="update.php?q=rmquiz&eid='.$eid.'" class="pull-right btn sub1" style="margin:0px;background:red;color:black">&nbsp;<span>Remove</span></a></b></center></td></tr>';
                        }
                        $c=0;
                        echo '</table></center></div></div>';
                    }
                ?>

                <?php
                    if(@$_GET['q']==6) 
                    {
                        echo
                        '<form class="f6" action="send.php" method="post" enctype="multipart/form-data">
                        <center>
                        <table style="width: 50%;">
                        
                        <tr><td>Email</td></tr>
                        <tr><td><input type="email" name="email" value="" class="a6"></td></tr>
                        <tr><td>Subject</td></tr>
                        <tr><td><input type="text" name="subject" value="" class="a6"> </td></tr>
                        <tr><td>Message </td></tr>
                        <tr><td><input type="text" name="message" value="" class="a6"> <br> <br>
                        <tr><td><input type="file" name="files[]" multiple="multiple" value=""></td></tr>
                        <tr><td><br><button type="submit" name="send" class="btn">Send</button></td></tr>
                         
                        </table>
                        </center>
                        </form>';
                    }
                ?>
            </div>
        </div>
    </div>


</body>
</html>
