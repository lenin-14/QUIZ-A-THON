<?php
    include_once 'database.php';
    session_start();
    if(!(isset($_SESSION['email'])))
    {
        header("location:login.php");
    }
    else
    {
        $name = $_SESSION['name'];
        $email = $_SESSION['email'];
        include_once 'database.php';
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome | QuizBuzz</title>
    <style>
        body {
        font-family: Lato, Helvetica, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.58;
        color: white;
        width: 100%;
        background: url(image/book.png);
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }

      h1 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 400;
        line-height: 1.1;
        font-size: 63px;
        font-stretch: extra-condensed;
        margin-bottom: 0;
      }

      h2 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 500;
        font-size: 40px;
        line-height: 1.1;
        font-stretch: condensed;
      }

      p {
        margin-top: 10px;
        color: white;
      }

      table {
        padding: 20px;
        background-color: #545458 ;
        width: 80%;
        border-radius: 5px;
        margin-top: 10px;
      }

      th {
        font-size: 35px;
        font-weight: bold;
        font-stretch: extra-condensed;
      }

      td {
        color: white;
        font-size: 15px;
      }

      i {
        color: white;
        font-size: 90px;
        width: 40px;
      }

      input[type="text"]{
        font: inherit;
        padding: 8px 16px 8px 16px;
        width: 90%;
        background-color: #f0ecec;
        border-style: none;
        border-radius: 3px
      }

      input[type="radio"]{
        height: 20px;
        width: 20px;
        border-radius: 50%;
        background-color: #2196F3;
      }

      .form-control {
        display: block;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
      }

      .btn {
        display: inline-block;
        margin-bottom: 0;
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        border: none;
        padding: 8px 16px;
        font-size: 13px;
        line-height: 1.58;
        border-radius: 50px;
        color: #fff;
        background-color:black;
      }
  ul.nav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}
ul.nav li {float: left;}
ul.topnav li.right {float: right;}
ul.nav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
ul.nav li a:hover:not(.active) {
    background-color: #111;
}

ul.nav li a.active {
    background-color: purple;
}

ul.nav li.right {
    float: right;
}
@media screen and (max-width: 600px) {
  ul.nav li.right,
  ul.nav li {float: none;}
}


</style>
</head>
<body>
        <ul class="nav">
            <li <?php if(@$_GET['q']==1) echo'class="active"'; ?> ><a href="welcome.php?q=1">&nbsp;Home</a></li>
            <li <?php if(@$_GET['q']==2) echo'class="active"'; ?>> <a href="welcome.php?q=2">&nbsp;History</a></li>
            <li <?php if(@$_GET['q']==3) echo'class="active"'; ?>> <a href="welcome.php?q=3">&nbsp;Ranking</a></li>
            <li <?php if(@$_GET['q']==4) echo'class="active"'; ?>> <a href="welcome.php?q=4">&nbsp;Upload</a></li>
            <li class="right" <?php echo''; ?> > <a href="logout.php?q=welcome.php">&nbsp;Log out</a></li>
        </ul>

   
    <br><br>
    <div class="container">
        <div class="row">
            <div>
                <?php if(@$_GET['q']==1)
                {
                    $result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
                    echo  '<center><table><tr><td><center><b>S.N.</b></center></td><td><center><b>Topic</b></center></td><td><center><b>Total question</b></center></td><td><center><b>Marks</center></b></td><td><center><b>Action</b></center></td><td><center><b>Difficulty</b></center></td></tr>';
                    $c=1;
                    while($row = mysqli_fetch_array($result)) {
                        $title = $row['title'];
                        $total = $row['total'];
                        $sahi = $row['sahi'];
                        $eid = $row['eid'];
                        $diff = $row['difficulty'];

                    $q12=mysqli_query($con,"SELECT score FROM history WHERE eid='$eid' AND email='$email'" )or die('Error98');
                    $rowcount=mysqli_num_rows($q12);
                    if($rowcount == 0){
                        echo '<tr><td><center>'.$c++.'</center></td><td><center>'.$title.'</center></td><td><center>'.$total.'</center></td><td><center>'.$sahi*$total.'</center></td><td><center><b><a href="welcome.php?q=quiz&step=2&eid='.$eid.'&n=1&t='.$total.'" class="btn" style="color:black;margin:0px;background:#1de9b6">&nbsp;<b style="text-decoration:none;">Start</b></a></b></center></td><td><center>'.$diff.'</center></td></tr>';
                    }
                    else
                    {
                    echo '<tr style="color:#99cc32"><td><center>'.$c++.'</center></td><td><center>'.$title.'&nbsp;<span title="This quiz is already solve by you"></span></center></td><td><center>'.$total.'</center></td><td><center>'.$sahi*$total.'</center></td><td><center><b><a href="update.php?q=quizre&step=25&eid='.$eid.'&n=1&t='.$total.'" class="btn" style="color:black;margin:0px;background:red">&nbsp;<span><b style="text-decoration:none;">Restart</b></span></a></b></center></td><td><center>'.$diff.'</center></td></tr>';
                    }
                    }
                    $c=0;
                    echo '</table></center></div></div>';
                }?>

                <?php
                    if(@$_GET['q']== 'quiz' && @$_GET['step']== 2)
                    {
                        $eid=@$_GET['eid'];
                        $sn=@$_GET['n'];
                        $total=@$_GET['t'];
                        $q=mysqli_query($con,"SELECT * FROM questions WHERE eid='$eid' AND sn='$sn' " );
                        echo '<div style="margin:5%">';
                        while($row=mysqli_fetch_array($q) )
                        {
                            $qns=$row['qns'];
                            $qid=$row['qid'];
                            echo '<b>Question &nbsp;'.$sn.'&nbsp;::<br /><br />'.$qns.'</b><br /><br />';
                        }
                        $q=mysqli_query($con,"SELECT * FROM options WHERE qid='$qid' " );
                        echo '<form action="update.php?q=quiz&step=2&eid='.$eid.'&n='.$sn.'&t='.$total.'&qid='.$qid.'" method="POST">
                        <br />';

                        while($row=mysqli_fetch_array($q) )
                        {
                            $option=$row['option'];
                            $optionid=$row['optionid'];
                            echo'<input type="radio" name="ans" value="'.$optionid.'">&nbsp;'.$option.'<br /><br />';
                        }
                        echo'<br /><button type="submit" class="btn">&nbsp;Submit</button></form></div>';
                    }

                    if(@$_GET['q']== 'result' && @$_GET['eid'])
                    {
                        $eid=@$_GET['eid'];
                        $q=mysqli_query($con,"SELECT * FROM history WHERE eid='$eid' AND email='$email' " )or die('Error157');
                        echo  '<div>
                        <center><h1 style="color:white">Result</h1><center><br /><center><table style="font-size:20px;font-weight:1000;">';

                        while($row=mysqli_fetch_array($q) )
                        {
                            $s=$row['score'];
                            $w=$row['wrong'];
                            $r=$row['sahi'];
                            $qa=$row['level'];
                            echo '<tr><td>Total Questions</td><td>'.$qa.'</td></tr>
                                <tr><td>Right Answer&nbsp;</td><td>'.$r.'</td></tr>
                                <tr><td>Wrong Answer&nbsp;</td><td>'.$w.'</td></tr>
                                <tr><td>Score&nbsp;</td><td>'.$s.'</td></tr>';
                        }
                        $q=mysqli_query($con,"SELECT * FROM rank WHERE  email='$email' " )or die('Error157');
                        while($row=mysqli_fetch_array($q) )
                        {
                            $s=$row['score'];
                            echo '<tr style="color:#990000"><td>Overall Score&nbsp;</td><td>'.$s.'</td></tr>';
                        }
                        echo '</table></center></div>';
                    }
                ?>

                <?php
                    if(@$_GET['q']== 2)
                    {
                        $q=mysqli_query($con,"SELECT * FROM history WHERE email='$email' ORDER BY date DESC " )or die('Error197');
                        echo  '<div>
                        <center><table><tr style="color:black;"><td><center><b>S.N.</b></center></td><td><center><b>Quiz</b></center></td><td><center><b>Question Solved</b></center></td><td><center><b>Right</b></center></td><td><center><b>Wrong<b></center></td><td><center><b>Score</b></center></td>';
                        $c=0;
                        while($row=mysqli_fetch_array($q) )
                        {
                        $eid=$row['eid'];
                        $s=$row['score'];
                        $w=$row['wrong'];
                        $r=$row['sahi'];
                        $qa=$row['level'];
                        $q23=mysqli_query($con,"SELECT title FROM quiz WHERE  eid='$eid' " )or die('Error208');

                        while($row=mysqli_fetch_array($q23) )
                        {  $title=$row['title'];  }
                        $c++;
                        echo '<tr><td><center>'.$c.'</center></td><td><center>'.$title.'</center></td><td><center>'.$qa.'</center></td><td><center>'.$r.'</center></td><td><center>'.$w.'</center></td><td><center>'.$s.'</center></td></tr>';
                        }
                        echo'</table></center></div>';
                    }

                    if(@$_GET['q']== 3)
                    {
                        $q=mysqli_query($con,"SELECT * FROM rank ORDER BY score DESC " )or die('Error223');
                        echo  '<div><div><center><table>
                        <tr style="color:red"><td><center><b>Rank</b></center></td><td><center><b>Name</b></center></td><td><center><b>Email</b></center></td><td><center><b>Score</b></center></td></tr>';
                        $c=0;

                        while($row=mysqli_fetch_array($q) )
                        {
                            $e=$row['email'];
                            $s=$row['score'];
                            $q12=mysqli_query($con,"SELECT * FROM user WHERE email='$e' " )or die('Error231');
                            while($row=mysqli_fetch_array($q12) )
                            {
                                $name=$row['name'];
                            }
                            $c++;
                            echo '<tr><td style="color:black"><center><b>'.$c.'</b></center></td><td><center>'.$name.'</center></td><td><center>'.$e.'</center></td><td><center>'.$s.'</center></td></tr>';
                        }
                        echo '</table></center></div></div>';
                    }
                ?>

              <?php
              if(@$_GET['q']== 4)
              {
                echo '<div id="wrapper">
                
            <! specify the encoding type of the form using the

                enctype attribute >

<h3><center>
Upload the question you feel is wrong as an image
</center></h3>
        <form method="POST" action="" enctype="multipart/form-data">
        <center>

        <table style="width:16%">
            <tr>
                <td><center><input type="file" name="choosefile" value="" /></center></td>
            </tr>     
            <tr>
                <td><br><center><button type="submit" name="upload" class="btn">UPLOAD</button></center></td>
                </tr>   
        </table>  
        </center>
        </form>
    </div>';

if (isset($_POST['upload'])) {

   $filename = $_FILES["choosefile"]["name"];
   $tempname = $_FILES["choosefile"]["tmp_name"];
   $folder = "./user_upload/".$filename;


  mysqli_query($con,"INSERT INTO image (filename) VALUES ('$filename')" );


   // Now let's move the uploaded image into the folder: image
   if (move_uploaded_file($tempname, $folder)) {
       echo "<script>alert('Image uploaded successfully!!');</script>";
   } else {
       echo "<script>alert('Image not uploaded!!');</script>";
   }
}
}
?>
</body>


</html>