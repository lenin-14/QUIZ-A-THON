<?php
	include("database.php");
	session_start();
	
	if(isset($_POST['submit']))
	{	
		$name = $_POST['name'];
		$name = stripslashes($name);
		$name = addslashes($name);

		$email = $_POST['email'];
		$email = stripslashes($email);
		$email = addslashes($email);

		$password = $_POST['password'];
		$password = stripslashes($password);
		$password = addslashes($password);

		$college = $_POST['college'];
		$college = stripslashes($college);
		$college = addslashes($college);
		$str="SELECT email from user WHERE email='$email'";
		$result=mysqli_query($con,$str);
		
		if((mysqli_num_rows($result))>0)	
		{
            echo "<center><h3><script>alert('Sorry.. This email is already registered !!');</script></h3></center>";
            header("refresh:0;url=login.php");
        }
		else
		{
            $str="insert into user set name='$name',email='$email',password='$password',college='$college'";
			if((mysqli_query($con,$str)))	
			echo "<center><h3><script>alert('Congrats.. You have successfully registered !!');</script></h3></center>";
			header('location: welcome.php?q=1');
		}
    }
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>Register | QuizBuzz</title>
        <style>
            
				body {
        font-family: Lato, Helvetica, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
        width: 100%;
        background: url(image/book.png);
        background-position: center center;
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
      }

      h1 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 400;
        line-height: 1.1;
        font-size: 63px;
        font-stretch: extra-condensed;
        margin-bottom: 0;
      }

      h2 {
        font-family: Oswald, Helvetica, Arial, sans-serif;
        color: white;
        font-weight: 500;
        font-size: 40px;
        line-height: 1.1;
        font-stretch: condensed;
      }

      p {
        margin-top: 10px;
        color: white;
      }

      table {
        padding: 20px;
        background-color: #545458;
        width: 40%;
        border-radius: 5px
      }

      th {
        font-size: 35px;
        font-weight: bold;
        font-stretch: extra-condensed;
      }

      td {
        color: white;
        font-size: 15px;
      }

      i {
        color: white;
        font-size: 90px;
        width: 40px;
      }

      input,
      textarea {
        font: inherit;
        padding: 8px 16px 8px 16px;
        width: 90%;
        background-color: #f0ecec;
        border-style: none;
        border-radius: 3px
      }

      .form-control {
        display: block;
        font-size: 16px;
        line-height: 1.58;
        color: #555;
      }

      .btn {
        display: inline-block;
        margin-bottom: 0;
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        border: none;
        padding: 8px 16px;
        font-size: 16px;
        line-height: 1.58;
        border-radius: 50px;
        color: #fff;
        background-color:black;
      }

          </style>
	</head>

	<body>
		<center> <h2 style="font-family: Noto Sans;">SignUp</h2></center><br>
		<center>	                             
		<form method="post" action="register.php" enctype="multipart/form-data">
		<table>
			<tr>
				<td><label>Enter Your Username:</label></td>
			</tr>
			<tr>
				<td><input type="text" name="name" class="form-control" required /></td>
			</tr>
			<tr>
				<td><label>Enter Your Email Id:</label></td>
			</tr>
			<tr>
				<td><input type="email" name="email" class="form-control" required /></td>
			</tr>
			<tr>
				<td><label>Enter Your Password:</label></td>
			</tr>
			<tr>
				<td><input type="password" name="password" class="form-control" required /></td>
			</tr>
			<tr>
				<td><label>Enter Your College Name:</label></td>
			</tr>
			<tr>
				<td><input type="text" name="college" class="form-control" required /></td>
			</tr>
			<tr>
				<td><button class="btn" name="submit">SignUp</button></td>
			</tr>
			<tr>
				<td><span class="text-muted">Already have an account! </span> <a href="login.php">Login </a> Here..</td>
			</tr>
		</table>
	</center>

		</form>
			
	</body>
</html>